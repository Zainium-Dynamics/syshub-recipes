/* GnuTLS --- Guile bindings for GnuTLS.
   Copyright (C) 2007-2025 Free Software Foundation, Inc.

   This file is part of Guile-GnuTLS.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this library; if not, see <https://www.gnu.org/licenses/>. */

#ifndef GUILE_GNUTLS_ERRORS_H
# define GUILE_GNUTLS_ERRORS_H

# include <libguile.h>

# include "utils.h"

SCM_API void
scm_gnutls_error_with_args (int, const char *, SCM)
  NO_RETURN;

     SCM_API void scm_gnutls_error (int, const char *) NO_RETURN;

     SCM_API void scm_init_gnutls_error (void);

#endif
